import React from "react";

import { Paper } from "@mui/material";

import Table from "../../ui/Table";

import { payslipColumns } from "./PayslipColumn";

const PayslipTable = ({
  payslips,
  loading,
  onView,
  onDownload,
  rowCount,
  paginationModel,
  onPaginationModelChange,
  serialStart,
}) => {
  return (
    <Paper
      elevation={0}
      sx={{
        borderRadius: "20px",
        overflow: "hidden",

        background: "#23255E",

        border: "1px solid rgba(255,255,255,0.08)",

        p: 1,

        boxShadow: "0 12px 24px rgba(0,0,0,0.18), 0 4px 8px rgba(0,0,0,0.12)",
      }}
    >
      <Table
        rows={payslips}
        columns={payslipColumns(onView, onDownload, serialStart)}
        loading={loading}
        height={550}
        paginationMode="server"
        rowCount={rowCount}
        paginationModel={paginationModel}
        onPaginationModelChange={onPaginationModelChange}
      />
    </Paper>
  );
};

export default PayslipTable;

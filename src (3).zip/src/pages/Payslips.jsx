import React, { useState, useEffect } from "react";

import PayslipHeader from "../components/Payslips/PayslipHeader";
import PayslipStatusTabs from "../components/Payslips/PayslipStatusTabs";
import PayslipFilter from "../components/Payslips/PayslipFilter";
import PayslipTable from "../components/Payslips/PayslipTable";
import GlobalModal from "../ui/GlobalModal";
import {
  downloadPayslip,
  getEmployeeHistory,
  viewPayslip,
} from "../services/payroll";
import dayjs from "dayjs";

const Payslips = () => {
  const [loading, setLoading] = useState(false);

  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewUrl, setPreviewUrl] = useState(null);
  const [previewLoading, setPreviewLoading] = useState(false);

  const [payslips, setPayslips] = useState([]);

  const [rowCount, setRowCount] = useState(0);
  const [selectedStatus, setSelectedStatus] = useState("ALL");

  const [selectedMonth, setSelectedMonth] = useState(dayjs());
  const [openMonthYearModal, setOpenMonthYearModal] = useState(false);

  const [paginationModel, setPaginationModel] = useState({
    page: 0,
    pageSize: 10,
  });

  const [filters, setFilters] = useState({
    search: "",
    emailVerified: "",
  });

  const fetchPayslips = async () => {
    try {
      setLoading(true);

      const payload = {
        search: filters.search,
        month: Number(selectedMonth.format("MM")),
        year: Number(selectedMonth.format("YYYY")),
        emailVerified: filters.emailVerified,
        status: selectedStatus === "ALL" ? null : selectedStatus,
        page: paginationModel.page,
        size: paginationModel.pageSize,
      };

      const response = await getEmployeeHistory(payload);

      console.log("Employee History:", response.data);

      setPayslips(response.data?.content || []);
      setRowCount(response.data?.totalElements || 0);
    } catch (error) {
      console.error("Failed to fetch payslips:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayslips();
  }, [
    selectedMonth,
    selectedStatus,
    filters,
    paginationModel.page,
    paginationModel.pageSize,
  ]);

  const serialStart = paginationModel.page * paginationModel.pageSize;

  const handleFilterChange = (field, value) => {
    setFilters((prev) => ({
      ...prev,
      [field]: value,
    }));

    setPaginationModel((prev) => ({
      ...prev,
      page: 0,
    }));
  };

  const handleDownload = async (employeePayrollId) => {
    try {
      const response = await downloadPayslip(employeePayrollId);

      const blob = new Blob([response.data], {
        type: "application/pdf",
      });

      const url = window.URL.createObjectURL(blob);

      const link = document.createElement("a");
      link.href = url;
      link.download = `Payslip_${employeePayrollId}.pdf`;

      document.body.appendChild(link);
      link.click();

      link.remove();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error("Download failed:", error);
    }
  };

  const handleView = async (id) => {
    try {
      if (previewUrl) {
        window.URL.revokeObjectURL(previewUrl);
      }

      setPreviewOpen(true);
      setPreviewLoading(true);

      const response = await viewPayslip(id);

      const blob = new Blob([response.data], {
        type: "application/pdf",
      });

      const url = window.URL.createObjectURL(blob);

      setPreviewUrl(url);
    } catch (error) {
      console.error("View failed:", error);
      setPreviewOpen(false);
    } finally {
      setPreviewLoading(false);
    }
  };

  useEffect(() => {
    return () => {
      if (previewUrl) {
        window.URL.revokeObjectURL(previewUrl);
      }
    };
  }, [previewUrl]);

  const handleClosePreview = () => {
    if (previewUrl) {
      window.URL.revokeObjectURL(previewUrl);
    }

    setPreviewUrl(null);
    setPreviewOpen(false);
  };

  const handleReset = () => {
    setFilters({
      search: "",
      emailVerified: "",
    });

    setSelectedMonth(dayjs());

    setSelectedStatus("ALL");

    setPaginationModel({
      page: 0,
      pageSize: 10,
    });
  };

  const handleStatusChange = (status) => {
    setSelectedStatus(status);

    setPaginationModel((prev) => ({
      ...prev,
      page: 0,
    }));
  };

  const handleExport = () => {
    console.log("Export Payslip Report");
  };

  return (
    <>
      <PayslipHeader
        selectedMonth={selectedMonth}
        setSelectedMonth={setSelectedMonth}
        onExportReport={handleExport}
      />

      <PayslipFilter
        filters={filters}
        onFilterChange={handleFilterChange}
        onReset={handleReset}
      />

      <PayslipStatusTabs
        selectedStatus={selectedStatus}
        onStatusChange={handleStatusChange}
      />

      <PayslipTable
        payslips={payslips}
        loading={loading}
        rowCount={rowCount}
        paginationModel={paginationModel}
        onPaginationModelChange={setPaginationModel}
        serialStart={serialStart}
        onDownload={handleDownload}
        onView={handleView}
      />

      <GlobalModal
        open={previewOpen}
        handleClose={handleClosePreview}
        title="Payslip Preview"
        subtitle="View Only"
        maxWidth={850}
      >
        <div style={{ height: "75vh", width: "100%" }}>
          {previewLoading ? (
            <div
              style={{
                display: "flex",
                justifyContent: "center",
                alignItems: "center",
                height: "100%",
              }}
            >
              Loading...
            </div>
          ) : (
            previewUrl && (
              <iframe
                src={previewUrl}
                title="Payslip Preview"
                width="100%"
                height="100%"
                style={{
                  border: "none",
                  borderRadius: "8px",
                }}
              />
            )
          )}
        </div>
      </GlobalModal>
    </>
  );
};

export default Payslips;

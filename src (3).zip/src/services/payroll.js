import api from "./api";

export const downloadPayrollTemplate = () =>
  api.post(
    "/ctpl/payroll/template",
    {},
    {
      responseType: "blob",
    },
  );

export const generatePayrollEmails = (data) =>
  api.post("/ctpl/payroll/submit", data);

export const getEmployeeHistory = (data) =>
  api.post("/ctpl/payroll/employee-history", data);

export const downloadPayslip = (employeePayrollId) =>
  api.get(`/ctpl/payroll/payslip/download/${employeePayrollId}`, {
    responseType: "blob",
  });

export const viewPayslip = (id) =>
  api.get(`/ctpl/payroll/payslip/view/${id}`, {
    responseType: "blob",
  });